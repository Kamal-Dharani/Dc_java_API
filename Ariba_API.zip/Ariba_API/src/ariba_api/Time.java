/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ariba_api;

/**
 *
 * @author Ariba
 */
/*
 * The Time class models a time instance with second, minute and hour.
 * This class does not perform input validation for second, minute and hour.
 */
public class Time {
   // The private instance variables
   private int second, minute, hour;

   // The constructors (overloaded)
   public Time(int second, int minute, int hour) {
      // No input validation
      this.second = second;
      this.minute = minute;
      this.hour = hour;
   }
   public Time() {  // the default constructor
      this.second = 0;
      this.minute = 0;
      this.hour = 0;
   }

   // The public getters/setters for the private variables.
   public int getSecond() {
      return this.second;
   }
   public int getMinute() {
      return this.minute;
   }
   public int getHour() {
      return this.hour;
   }
   public void setSecond(int second) {
      this.second = second;  // No input validation
   }
   public void setMinute(int minute) {
      this.minute = minute;  // No input validation
   }
   public void setHour(int hour) {
      this.hour = hour;  // No input validation
   }

   // Return "hh:mm:ss" with leading zeros.
   public String toString() {
        // Use built-in function String.format() to form a formatted String
        return String.format("%02d:%02d:%02d", hour, minute, second);
              // Specifier "0" to print leading zeros, if available.
   }

   // Set second, minute and hour
   public void setTime(int second, int minute, int hour) {
      // No input validation
      this.second = second;
      this.minute = minute;
      this.hour = hour;
   }

   // Increment this instance by one second, and return this instance.
   public Time nextSecond() {
      ++second;
      if (second >= 60) {
         second = 0;
         ++minute;
         if (minute >= 60) {
            minute = 0;
            ++hour;
            if (hour >= 24) {
               hour = 0;
            }
         }
      }
      return this;   // Return "this" instance, to support chaining
                     // e.g., t1.nextSecond().nextSecond()
   }
}